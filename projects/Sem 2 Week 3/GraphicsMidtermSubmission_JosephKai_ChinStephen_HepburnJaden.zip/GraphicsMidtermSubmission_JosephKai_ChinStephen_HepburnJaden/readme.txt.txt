Kai Joseph - 100783670
Stephen Chin - 100786592
Jaden Hepburn - 100791169

Intermediate Graphics Midterm Submission

Executable file is called Sem 2 Week 3

